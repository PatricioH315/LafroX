/* Administración: personas usuarias, roles y permisos (RBAC), parametrización con
   aprobación de un segundo perfil y consulta de auditoría. */
(function (L) {
  const { esc, icon, $, $$, data: D, fmt } = L;
  // Business names of the functional modules shown to users
  const roleName = (id) => D.roles.find((r) => r.id === id)?.nombre || id;

  const importKey = 'admin.usuariosImportados';
  function csvRows(content) {
    const rows = [];
    let row = [], value = '', quoted = false, closed = false;
    const push = () => { row.push(value.trim()); value = ''; closed = false; };
    for (let i = 0; i < content.length; i++) {
      const c = content[i];
      if (quoted) {
        if (c !== '"') value += c;
        else if (content[i + 1] === '"') { value += '"'; i++; }
        else { quoted = false; closed = true; }
      } else if (c === ';') push();
      else if (c === '\n' || c === '\r') {
        if (c === '\r' && content[i + 1] === '\n') i++;
        push(); rows.push(row); row = [];
      } else if (c === '"' && !closed && !value.trim()) { value = ''; quoted = true; }
      else if (c === '"' || (closed && c.trim())) throw new Error('Comillas CSV incorrectas.');
      else value += c;
    }
    if (quoted) throw new Error('Hay un campo entre comillas sin cerrar.');
    push(); rows.push(row);
    return rows;
  }

  function importPeople(content) {
    const rows = csvRows(content.replace(/^\uFEFF/, ''));
    const header = rows.shift().map((v) => v.toLowerCase());
    if (header.join(';') !== 'nombre;correo;rol;sitio') throw new Error('Use el encabezado nombre;correo;rol;sitio.');
    const seen = new Set(D.usuarios.map((u) => u.correo.toLowerCase()));
    const stored = L.store.get(importKey, []);
    const people = [], errors = [];
    rows.forEach((cells, i) => {
      if (cells.length === 1 && !cells[0]) return;
      const [nombre, rawEmail, rawRole, rawSite] = cells;
      const correo = rawEmail?.toLowerCase();
      const role = D.roles.find((r) => r.id === rawRole?.toLowerCase() || r.nombre.toLowerCase() === rawRole?.toLowerCase());
      const site = D.sitios.find((s) => s.nombre.toLowerCase() === rawSite?.toLowerCase() || s.id.toLowerCase() === rawSite?.toLowerCase());
      const error = cells.length !== 4 || !nombre ? 'Se requieren las cuatro columnas y el nombre.'
        : L.validators.email(correo) || (!correo.endsWith('@puelche.cl') ? 'Se requiere un correo @puelche.cl.' : '')
        || (seen.has(correo) ? 'Correo duplicado.' : '') || (!role ? 'Rol desconocido.' : '') || (!site ? 'Sitio desconocido.' : '');
      if (error) { errors.push('Registro ' + (i + 1) + ': ' + error); return; }
      seen.add(correo);
      people.push({ id: 'U-CSV-' + (stored.length + people.length + 1), nombre, correo, rol: role.id, sitio: site.nombre, estado: 'Pendiente', mfa: false, ultimo: null });
    });
    if (people.length) {
      L.store.set(importKey, [...stored, ...people]);
      D.usuarios.unshift(...people);
    }
    return { added: people.length, errors };
  }

  L.route('/admin/usuarios', {
    title: 'Personas usuarias', parent: '/inicio', block: 'Administración', module: 'Base compartida (Keycloak)', rf: ['RF-17.01', 'RF-15.05', 'RF-15.03'], actors: ['Jefe de TI'],
    render: () => `<div class="page-head"><div class="titles"><h1>Personas usuarias</h1><p class="muted" style="margin:0">Altas, bajas, roles y segundo factor, sin intervención del proveedor.</p></div><div class="actions"><button type="button" class="btn btn-secondary" id="us-imp">${icon('upload')}Importar CSV</button><button type="button" class="btn btn-primary" id="us-new">${icon('plus')}Invitar persona</button></div></div>
      <div class="grid grid-2" style="margin-bottom:var(--sp-5)">
        <section class="card"><div class="card-head"><h2>Unidades organizacionales</h2><button type="button" class="btn btn-secondary btn-sm" id="ou-new">${icon('plus', 'icon-sm')}Nueva unidad</button></div><ul class="list" id="ou-l"></ul><p class="small muted">Jerarquía que el CLIENTE administra sin intervención del proveedor; los permisos y aprobaciones se heredan por unidad.</p></section>
        <section class="card"><div class="card-head"><h2>Sincronización con Recursos Humanos</h2><button type="button" class="btn btn-secondary btn-sm" id="hr-sim">Simular desvinculación</button></div><p class="small muted" style="margin-top:0">Altas y bajas ligadas al ciclo laboral: una desvinculación suspende la cuenta en todos los módulos en menos de 24 h.</p><ul class="list" id="hr-l"></ul></section></div>
      <div class="card card-flush" id="us-t"></div>`,
    mount: (root, p, q) => {
      const restored = L.store.get(importKey, []).filter((person) => !D.usuarios.some((u) => u.id === person.id));
      D.usuarios.unshift(...restored);
      const tbl = L.dataTable($('#us-t', root), {
        id: 'us', caption: 'Personas usuarias', rows: D.usuarios, searchKeys: ['nombre', 'correo', 'sitio'], searchPlaceholder: 'Buscar por nombre o correo',
        filters: [{ key: 'rol', label: 'Rol', options: D.roles.map((r) => r.id) }, { key: 'estado', label: 'Estado', options: ['Activo', 'Suspendido', 'Pendiente'] }],
        sort: 'nombre', selectable: true,
        columns: [
          { key: 'nombre', label: 'Persona', render: (r) => `<div class="row" style="flex-wrap:nowrap"><span class="avatar" style="width:36px;height:36px">${esc(L.initials(r.nombre))}</span><div>${esc(r.nombre)}<div class="small muted">${esc(r.correo)}</div></div></div>` },
          { key: 'rol', label: 'Rol', render: (r) => esc(roleName(r.rol)) }, { key: 'sitio', label: 'Sitio' },
          { key: 'mfa', label: 'Segundo factor', render: (r) => (r.mfa ? L.badge('Exigido', 'success') : L.badge('No exigido', '')) },
          { key: 'ultimo', label: 'Último acceso', render: (r) => (r.ultimo ? fmt.dt(r.ultimo) : '—'), sortVal: (r) => r.ultimo },
          { key: 'estado', label: 'Estado', render: (r) => L.badge(r.estado, r.estado === 'Activo' ? 'success' : r.estado === 'Suspendido' ? 'danger' : 'warning') }
        ],
        rowActions: (r, redraw) => [
          { label: 'Cambiar rol', icon: 'key', onClick: () => roleModal(r, redraw) },
          { label: 'Restablecer segundo factor', icon: 'fingerprint', onClick: () => L.toast('Segundo factor restablecido', `${r.nombre} deberá enrolarlo en su próximo ingreso.`, 'success') },
          { sep: true },
          r.estado === 'Suspendido' ? { label: 'Reactivar', icon: 'check', onClick: () => { r.estado = 'Activo'; redraw(); L.toast('Cuenta reactivada', r.nombre, 'success'); } } : { label: 'Suspender acceso', icon: 'ban', danger: true, onClick: async () => { if (await L.confirm({ title: `¿Suspender a ${r.nombre}?`, message: 'Se cerrarán sus sesiones en todos los módulos de inmediato (baja efectiva).', confirmLabel: 'Suspender', danger: true })) { L.logAudit('Modificación', 'Usuario', `Acceso de ${r.nombre}`, 'Consola web', r.estado, 'Suspendido'); r.estado = 'Suspendido'; redraw(); L.toast('Acceso suspendido', 'Sesiones cerradas en todos los módulos.', 'success'); } } }
        ],
        bulkActions: [{ label: 'Exigir segundo factor', icon: 'fingerprint', onClick: (ids, done) => { D.usuarios.filter((u) => ids.includes(u.id)).forEach((u) => (u.mfa = true)); done(); L.toast('Segundo factor exigido', `${ids.length} persona(s).`, 'success'); } }, { label: 'Suspender', icon: 'ban', onClick: async (ids, done) => { if (await L.confirm({ title: `¿Suspender ${ids.length} cuenta(s)?`, message: 'Se cerrarán sus sesiones en todos los módulos.', confirmLabel: 'Suspender', danger: true, requireText: 'SUSPENDER' })) { D.usuarios.filter((u) => ids.includes(u.id)).forEach((u) => (u.estado = 'Suspendido')); done(); L.toast('Cuentas suspendidas', '', 'success'); } } }]
      });
      const roleModal = (u, redraw) => L.modal({ title: `Cambiar rol de ${u.nombre}`, body: `<div class="field"><label for="rl">Rol</label><select id="rl" class="select">${D.roles.map((r) => `<option value="${r.id}" ${r.id === u.rol ? 'selected' : ''}>${esc(r.nombre)}</option>`).join('')}</select></div><p class="hint">El cambio de rol requiere confirmación y queda en la auditoría.</p>`, actions: [{ label: 'Cancelar' }, { label: 'Guardar', cls: 'btn-primary', onClick: async (api) => { const v = $('#rl', api.el).value; if (v === u.rol) return; api.close(); if (await L.confirm({ title: 'Confirmar cambio de rol', message: `${esc(u.nombre)} pasará de «${esc(roleName(u.rol))}» a «${esc(roleName(v))}» y verá otro menú.`, confirmLabel: 'Confirmar cambio' })) { L.logAudit('Modificación', 'Usuario', `Rol de ${u.nombre}`, 'Consola web', roleName(u.rol), roleName(v)); u.rol = v; redraw(); L.toast('Rol actualizado', u.nombre, 'success'); } return false; } }] });
      const invite = () => L.modal({
        title: 'Invitar persona usuaria', size: 'lg',
        body: `<div class="form-grid"><div class="field"><label for="iv-n">Nombre completo <span class="req" aria-hidden="true">*</span></label><input id="iv-n" class="input" autocomplete="off"></div><div class="field"><label for="iv-e">Correo corporativo <span class="req" aria-hidden="true">*</span></label><input id="iv-e" class="input" type="email" placeholder="nombre@puelche.cl"></div>
          <div class="field"><label for="iv-r">Rol <span class="req" aria-hidden="true">*</span></label><select id="iv-r" class="select"><option value="">Seleccione…</option>${D.roles.map((r) => `<option value="${r.id}">${esc(r.nombre)}</option>`).join('')}</select></div><div class="field"><label for="iv-s">Sitio</label><select id="iv-s" class="select">${D.sitios.map((s) => `<option>${esc(s.nombre)}</option>`).join('')}</select></div>
          <div class="field"><label for="iv-d">Fecha de inicio</label><input id="iv-d" class="input" type="date" value="2026-11-16"></div><div class="field"><label for="iv-h">Vigencia hasta (opcional)</label><input id="iv-h" class="input" type="date"></div>
          <div class="full" id="iv-ext" hidden></div><div class="full"><label class="check"><input type="checkbox" id="iv-m" checked> Exigir segundo factor desde el primer ingreso</label></div></div>`,
        onOpen: (d) => { $('#iv-r', d).addEventListener('change', () => { const r = D.roles.find((x) => x.id === $('#iv-r', d).value); const ext = $('#iv-ext', d); ext.hidden = !r?.externo; ext.innerHTML = r?.externo ? L.alert('info', 'Alta de perfil externo', `${esc(r.externo)}. Estos perfiles no usan correo corporativo y no se crean con una invitación de TI.`) : ''; $('#iv-e', d).placeholder = r?.externo ? 'correo del representante (si corresponde)' : 'nombre@puelche.cl'; }); L.bindField($('#iv-n', d), ['required']); L.bindField($('#iv-e', d), ['email', (v) => (v.endsWith('@puelche.cl') || D.roles.find((x) => x.id === $('#iv-r', d).value)?.externo ? '' : 'Use un correo del dominio @puelche.cl.'), (v) => (D.usuarios.some((u) => u.correo === v) ? 'Ya existe una persona con ese correo.' : '')]); L.bindField($('#iv-r', d), ['required']); L.bindField($('#iv-h', d), [(v) => (!v || v > $('#iv-d', d).value ? '' : 'La vigencia debe terminar después del inicio.')]); },
        actions: [{ label: 'Cancelar' }, { label: 'Enviar invitación', cls: 'btn-primary', icon: 'send', onClick: async (api, btn) => { if (!L.validateAll(api.el)) return false; await L.busy(btn, () => {}, 800); D.usuarios.unshift({ id: 'U-' + (2000 + D.usuarios.length), nombre: $('#iv-n', api.el).value, correo: $('#iv-e', api.el).value, rol: $('#iv-r', api.el).value, sitio: $('#iv-s', api.el).value, estado: 'Pendiente', mfa: $('#iv-m', api.el).checked, ultimo: new Date().toISOString() }); tbl.draw(); L.toast('Invitación enviada', 'La persona recibirá un enlace de activación.', 'success'); } }]
      });
      $('#us-new', root).onclick = invite;
      $('#us-imp', root).onclick = () => L.modal({
        title: 'Importar personas desde CSV',
        body: `<div class="dropzone" id="imp-dz">${icon('upload', 'icon-lg')}<div><strong>Arrastre el archivo CSV</strong> o haga clic</div><span class="small">Encabezado: nombre;correo;rol;sitio</span></div><button type="button" class="btn btn-tertiary btn-sm" id="imp-f">Usar archivo de ejemplo</button><p class="hint">Las altas quedan pendientes en esta sesión de demostración. No se envían invitaciones ni se modifica ningún perfil.</p><div id="imp-out" role="status"></div>`,
        onOpen: (d) => {
          const z = L.dropzone($('#imp-dz', d), { accept: '.csv,text/csv', multiple: false, maxMB: 2 });
          $('#imp-f', d).onclick = () => z.add([new File(['nombre;correo;rol;sitio\nPersona de ejemplo;ejemplo.csv@puelche.cl;preventista;CD Talca'], 'personas-ejemplo.csv', { type: 'text/csv' })]);
          d._z = z;
        },
        actions: [{ label: 'Cerrar' }, { label: 'Validar e importar', cls: 'btn-primary', onClick: async (api, btn) => {
          const [file] = api.el._z.files;
          const out = $('#imp-out', api.el);
          if (!file) { out.textContent = 'Adjunte un archivo CSV.'; return false; }
          await L.busy(btn, async () => {
            try {
              const { added, errors } = importPeople(await file.text());
              tbl.draw();
              out.innerHTML = `<p><strong>${added} incorporadas · ${errors.length} omitidas</strong></p>${errors.length ? `<ul>${errors.slice(0, 10).map((error) => `<li>${esc(error)}</li>`).join('')}</ul>${errors.length > 10 ? '<p>Se muestran los primeros 10 errores.</p>' : ''}` : !added ? '<p>El archivo no contiene personas.</p>' : ''}${added ? '<p>Consulte las altas pendientes en la tabla de personas usuarias.</p>' : ''}`;
            } catch (error) { out.textContent = error.message || 'No se pudo leer el CSV.'; }
          }, 0);
          return false;
        } }]
      });
      if (q.nuevo) invite();
      const OU = () => L.store.get('org.units', [['Gerencia General', 0], ['Gerencia de Operaciones y Logística', 1], ['Bodega CD Talca', 2], ['Bodega CD Concepción', 2], ['Planificación de rutas', 2], ['Calidad y Aseguramiento', 1], ['Gerencia Comercial', 1], ['Preventa zona Curicó', 2], ['Gerencia de Administración y Finanzas', 1], ['Tecnologías de Información', 1]]);
      const drawOU = () => ($('#ou-l', root).innerHTML = OU().map(([n, lv]) => `<li style="padding-left:${lv * 20}px">${icon(lv ? 'chev-right' : 'home', 'icon-sm')}<span class="grow">${esc(n)}</span></li>`).join(''));
      drawOU();
      $('#ou-new', root).onclick = () => L.modal({ title: 'Nueva unidad organizacional', body: `<div class="form-grid"><div class="field"><label for="ou-n">Nombre <span class="req" aria-hidden="true">*</span></label><input id="ou-n" class="input"></div><div class="field"><label for="ou-p">Depende de <span class="req" aria-hidden="true">*</span></label><select id="ou-p" class="select"><option value="">Seleccione…</option>${OU().map(([n], i) => `<option value="${i}">${esc(n)}</option>`).join('')}</select></div></div>`, onOpen: (d) => { L.bindField($('#ou-n', d), ['required']); L.bindField($('#ou-p', d), ['required']); }, actions: [{ label: 'Cancelar' }, { label: 'Crear unidad', cls: 'btn-primary', onClick: (api) => { if (!L.validateAll(api.el)) return false; const list = OU(), pi = +$('#ou-p', api.el).value, n = $('#ou-n', api.el).value.trim(); let at = pi + 1; while (at < list.length && list[at][1] > list[pi][1]) at++; list.splice(at, 0, [n, list[pi][1] + 1]); L.store.set('org.units', list); L.logAudit('Creación', 'Unidad organizacional', `«${n}» creada bajo «${list[pi][0]}»`); drawOU(); L.toast('Unidad creada', n, 'success'); } }] });
      const HR = () => L.store.get('hr.bajas', [{ nombre: 'Rodrigo Arancibia Leiva', cargo: 'Preparador', desv: '12-11 18:00', baja: '12-11 18:42' }, { nombre: 'Valentina Muñoz Pino', cargo: 'Preventista', desv: '11-11 09:00', baja: '11-11 09:31' }]);
      const drawHR = () => ($('#hr-l', root).innerHTML = HR().map((h) => `<li>${icon('ban')}<div class="grow"><div class="title">${esc(h.nombre)} · ${esc(h.cargo)}</div><div class="sub">Desvinculación ${h.desv} · cuenta suspendida ${h.baja}</div></div>${L.badge('Baja efectiva', 'success')}</li>`).join(''));
      drawHR();
      $('#hr-sim', root).onclick = (e) => L.busy(e.currentTarget, () => { const u = D.usuarios.find((x) => x.estado === 'Activo' && !x._hr); if (!u) return; u._hr = true; u.estado = 'Suspendido'; const now = new Date().toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' }); L.store.set('hr.bajas', [{ nombre: u.nombre, cargo: roleName(u.rol), desv: `13-11 ${now}`, baja: `13-11 ${now}` }, ...HR()]); L.logAudit('Modificación', 'Usuario', `Baja automática por desvinculación informada por RR. HH.: ${u.nombre}`, 'API'); drawHR(); tbl.draw(); L.toast('Cuenta suspendida automáticamente', `${u.nombre}: sesiones cerradas en todos los módulos.`, 'success'); }, 900);
    }
  });


  const permissionNames = {
    'cliente.bloquear': 'Bloquear cliente por crédito', 'cliente.cartera': 'Consultar cartera', 'cliente.segmentar': 'Segmentar clientes',
    'cliente.crear': 'Crear cliente', 'cliente.editar': 'Editar cliente', 'cliente.ventana': 'Cambiar ventana de recepción',
    'precio.excepcion': 'Autorizar descuento excepcional', 'pedido.anular': 'Anular pedido', 'pedido.asignar': 'Asignar pedido a ruta',
    'pedido.autorizar': 'Autorizar o rechazar crédito', 'pedido.facturar': 'Revisar facturación', 'ruta.planificar': 'Planificar rutas',
    'ruta.aprobar': 'Aprobar rutas', 'ruta.restricciones': 'Gestionar restricciones de ruta', 'prep.misiones': 'Generar misiones de preparación',
    'recepcion.registrar': 'Registrar recepción', 'recepcion.ubicar': 'Ubicar pallets', 'erp.simular': 'Simular disponibilidad del ERP',
    'inv.gestionar': 'Gestionar inventario', 'inv.reposicion': 'Aprobar reposición', 'inv.ficha': 'Editar ficha de producto',
    'xd.causa': 'Registrar causa de cross-docking', 'dev.registrar': 'Registrar devolución', 'dev.recepcionar': 'Recepcionar devolución',
    'dev.destino': 'Aprobar destino de devolución', 'dev.nc': 'Solicitar nota de crédito', 'calidad.disponer': 'Decidir disposición sanitaria',
    'calidad.retiro': 'Ejecutar retiro sanitario', 'geocerca.gestionar': 'Gestionar geocercas', 'rend.gestionar': 'Gestionar rendición (Tesorería nominada, dentro de Finanzas)',
    'edi.gestionar': 'Gestionar canal EDI', 'asignacion.aprobar': 'Aprobar asignación conductor–vehículo–turno', 'rend.tipificar': 'Tipificar descuadre propio (sin aprobarlo)',
    'calidad.umbral.proponer': 'Proponer reglas de excursión', 'calidad.umbral.aprobar': 'Aprobar reglas de excursión'
  };
  const roleProposals = () => L.store.get('permisos.pendientes', []);
  // SD4 Capa 7: TI usa privilegios temporales, aprobados y auditados; no tiene permisos de negocio permanentes
  const jit = (root) => {
    const host = $('#ro-jit', root);
    if (!host) return;
    const me = L.me();
    const list = () => L.store.get('privilegios.temporales', []) || [];
    const canAsk = me.all || me.id === 'ti', canApprove = me.all || me.id === 'gerente-ops';
    const draw = () => {
      host.innerHTML = `<div class="card-head"><h2>Elevación temporal de privilegios</h2></div><p class="muted" style="margin:0">TI no tiene privilegios permanentes de alto riesgo: los solicita con motivo y una duración de hasta 8 horas, un segundo perfil los aprueba y todo queda en la auditoría.</p>
        ${canAsk ? `<div class="form-grid"><div class="field"><label for="jt-m">Motivo <span class="req" aria-hidden="true">*</span></label><input id="jt-m" class="input" placeholder="Ej.: restaurar la integración con el ERP"></div><div class="field"><label for="jt-h">Duración</label><select id="jt-h" class="select">${[1, 2, 4, 8].map((h) => `<option value="${h}">${h} h</option>`).join('')}</select></div></div><div><button type="button" class="btn btn-secondary" id="jt-ask">Solicitar elevación</button></div>` : ''}
        <ul class="list">${list().length ? list().map((x) => `<li><div class="grow"><div class="title">${esc(x.motivo)}</div><div class="sub">${x.horas} h · solicitada por ${esc(x.por)}${x.estado === 'Vigente' ? ' · vigente hasta ' + x.hasta : ''}</div></div>${L.badge(x.estado, x.estado === 'Vigente' ? 'success' : 'warning')}${x.estado === 'Pendiente' && canApprove && x.por !== me.name ? `<button type="button" class="btn btn-primary btn-sm" data-jt="${x.id}">Aprobar</button>` : ''}${x.estado === 'Pendiente' && x.por === me.name ? '<span class="small muted">Quien solicita no aprueba</span>' : ''}</li>`).join('') : '<li class="muted">Sin solicitudes.</li>'}</ul>`;
      const ask = $('#jt-ask', host);
      if (ask) ask.onclick = () => {
        const motivo = $('#jt-m', host).value.trim();
        if (motivo.length < 5) { L.toast('Indique el motivo', 'La elevación necesita una justificación.', 'warning'); return; }
        const horas = Number($('#jt-h', host).value);
        L.store.set('privilegios.temporales', [{ id: 'EP-' + Date.now(), motivo, horas, por: me.name, estado: 'Pendiente' }, ...list()]);
        L.logAudit('Creación', 'Privilegio', `Solicitud de elevación temporal de ${horas} h: ${motivo}`, 'Consola web');
        L.toast('Elevación solicitada', 'Un segundo perfil debe aprobarla.', 'success'); draw();
      };
      $$('[data-jt]', host).forEach((b) => (b.onclick = () => {
        const x = list().find((y) => y.id === b.dataset.jt); if (!x) return;
        const hasta = new Date(Date.now() + x.horas * 3600000).toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' });
        L.store.set('privilegios.temporales', list().map((y) => (y.id === x.id ? { ...y, estado: 'Vigente', hasta } : y)));
        L.logAudit('Aprobación', 'Privilegio', `Elevación temporal aprobada por ${me.name}, vigente hasta ${hasta}`, 'Consola web');
        L.toast('Elevación aprobada', `Vigente hasta ${hasta}; vence sola.`, 'success'); draw();
      }));
    };
    draw();
  };
  L.route('/admin/roles', {
    title: 'Roles y permisos', parent: '/inicio', block: 'Administración', module: 'Base compartida (RBAC)', rf: ['RF-15.04', 'RF-17.01', 'RF-17.03'], actors: ['Jefe de TI', 'Gerente de Operaciones'],
    render: () => `<div class="page-head"><div class="titles"><h1>Roles y permisos</h1><p class="muted">Permisos de acción de los perfiles de la demostración. No modifican las cuentas reales ni abren módulos fuera del menú del perfil.</p></div></div>
      <section class="card stack" id="ro-pending" aria-label="Propuestas pendientes"></section>
      <section class="card stack" id="ro-jit" style="margin-top:var(--sp-4)" aria-label="Elevación temporal de privilegios"></section>
      <section class="card stack" style="margin-top:var(--sp-4)"><div class="field"><label for="ro-profile">Perfil</label><select id="ro-profile" class="select">${D.profiles.filter((p) => !p.all).map((p) => `<option value="${p.id}">${esc(p.actor)}</option>`).join('')}</select></div>
      <div id="ro-matrix" class="table-wrap"></div><button type="button" class="btn btn-primary" id="ro-save" disabled>Enviar cambios a aprobación</button></section>`,
    mount: (root) => {
      jit(root);
      const me = L.me();
      const propose = me.all || me.id === 'ti';
      const review = me.all || me.id === 'gerente-ops';
      const profile = $('#ro-profile', root), matrix = $('#ro-matrix', root), save = $('#ro-save', root);
      const selectedChanges = () => $$('[data-permission]', matrix).filter((x) => x.checked !== L.profileCan(profile.value, x.dataset.permission))
        .map((x) => ({ action: x.dataset.permission, enabled: x.checked }));
      const drawMatrix = () => {
        matrix.innerHTML = `<table class="table"><caption class="sr-only">Permisos vigentes del perfil</caption><thead><tr><th scope="col">Acción</th><th scope="col">Permitida</th></tr></thead><tbody>${Object.keys(L.perm).map((action) => `<tr><th scope="row">${esc(permissionNames[action] || action)}</th><td><label class="check check-cell"><input type="checkbox" data-permission="${action}" aria-label="${esc(permissionNames[action] || action)}" ${L.profileCan(profile.value, action) ? 'checked' : ''} ${propose ? '' : 'disabled'}></label></td></tr>`).join('')}</tbody></table>`;
        save.hidden = !propose;
        save.disabled = true;
      };
      const drawPending = () => {
        const host = $('#ro-pending', root);
        const pending = roleProposals();
        host.innerHTML = `<h2>Cambios pendientes</h2>${pending.length ? `<ul class="stack">${pending.map((p) => `<li><strong>${esc(L.profile(p.profile)?.actor || p.profile)}</strong> · propuesto por ${esc(L.profile(p.by)?.name || p.by)}
          <ul>${p.changes.map((x) => `<li>${x.enabled ? 'Permitir' : 'Revocar'}: ${esc(permissionNames[x.action] || x.action)}</li>`).join('')}</ul>
          ${review && p.by !== me.id ? `<div class="btn-group"><button type="button" class="btn btn-primary" data-review="${p.id}" data-accept="yes">Aprobar</button><button type="button" class="btn btn-secondary" data-review="${p.id}" data-accept="no">Rechazar</button></div>` : '<p class="hint">Debe resolver otro perfil autorizado.</p>'}</li>`).join('')}</ul>` : '<p class="muted">No hay cambios pendientes.</p>'}`;
      };
      matrix.onchange = () => { save.disabled = !selectedChanges().length; };
      profile.onchange = drawMatrix;
      save.onclick = async () => {
        const actor = L.me();
        if (!actor?.all && actor?.id !== 'ti') return;
        const target = profile.value, changes = selectedChanges();
        if (!changes.length || !(await L.confirm({ title: '¿Enviar cambios a aprobación?', message: 'El permiso actual no cambia hasta que otro perfil apruebe.', confirmLabel: 'Enviar a aprobación' }))) return;
        if (L.me()?.id !== actor.id) return;
        const id = String(Date.now());
        L.store.set('permisos.pendientes', [...roleProposals(), { id, by: actor.id, profile: target, changes }]);
        L.logAudit('Creación', 'Permisos', 'Propuesta ' + id + ' para ' + L.profile(target).actor);
        drawMatrix(); drawPending();
        L.toast('Cambios enviados a aprobación', 'Gerencia de Operaciones puede resolverlos.', 'success');
      };
      $('#ro-pending', root).onclick = (event) => {
        const b = event.target.closest('[data-review]');
        const actor = L.me(), proposal = b && roleProposals().find((p) => p.id === b.dataset.review);
        if (!proposal || proposal.by === actor?.id || (!actor?.all && actor?.id !== 'gerente-ops')) return;
        const accept = b.dataset.accept === 'yes';
        if (accept) {
          const values = L.store.get('permisos.vigentes', {});
          for (const { action, enabled } of proposal.changes) {
            values[action] = { ...values[action], [proposal.profile]: enabled };
          }
          L.store.set('permisos.vigentes', values);
        }
        L.store.set('permisos.pendientes', roleProposals().filter((p) => p.id !== proposal.id));
        L.logAudit(accept ? 'Aprobación' : 'Rechazo', 'Permisos', 'Propuesta ' + proposal.id);
        drawMatrix(); drawPending();
        L.toast(accept ? 'Permisos actualizados' : 'Propuesta rechazada', '', accept ? 'success' : 'info');
      };
      drawMatrix(); drawPending();
    }
  });

  /* ---------- Flujos de aprobación configurables (RF-17.06) ---------- */
  const FLUJOS = () => L.store.get('flujos', [
    { id: 'F-1', nombre: 'Aprobación de devoluciones', estados: ['Registrada', 'En evaluación', 'Aprobada', 'Nota de crédito emitida'], plazo: 24, escala: 'Jefatura de Bodega', escalaH: 8 },
    { id: 'F-2', nombre: 'Autorización de pedido retenido por crédito', estados: ['Retenido', 'En revisión', 'Autorizado'], plazo: 4, escala: 'Gerencia de Finanzas', escalaH: 2 },
    { id: 'F-3', nombre: 'Cambio de parámetro (dos perfiles)', estados: ['Propuesto', 'En aprobación', 'Vigente'], plazo: 48, escala: 'Jefatura de TI', escalaH: 24 },
    { id: 'F-4', nombre: 'Disposición de producto retenido', estados: ['Retenido', 'En evaluación', 'Dispuesto'], plazo: 8, escala: 'Jefatura de Calidad', escalaH: 4 }
  ]);
  L.route('/admin/flujos', {
    title: 'Flujos de aprobación', parent: '/inicio', block: 'Administración', module: 'Base compartida (flujos)', rf: ['RF-17.06', 'RF-17.07'], actors: ['Jefe de TI'],
    render: () => `<div class="page-head"><div class="titles"><h1>Flujos de aprobación</h1><p class="muted" style="margin:0">Estados, transiciones, plazos y escalamiento de cada flujo, editables sin desarrollo y con registro en la auditoría.</p></div></div>
      <div class="stack" id="fl-list">${FLUJOS().map((f) => `<section class="card" aria-labelledby="${f.id}-h"><div class="card-head"><h2 id="${f.id}-h">${esc(f.nombre)}</h2><button type="button" class="btn btn-secondary btn-sm" data-fl="${f.id}" aria-label="Configurar ${esc(f.nombre)}">${icon('edit', 'icon-sm')}Configurar</button></div><ol class="timeline" aria-label="Estados y transiciones">${f.estados.map((e) => `<li><strong>${esc(e)}</strong></li>`).join('')}</ol><p class="small muted" style="margin:8px 0 0">Plazo por etapa: <strong>${f.plazo} h</strong> · si vence, escala a <strong>${esc(f.escala)}</strong> tras ${f.escalaH} h adicionales.</p></section>`).join('')}</div>
      <section class="card" style="margin-top:var(--sp-5)"><div class="card-head"><h2>Delegación por ausencia</h2><button type="button" class="btn btn-secondary btn-sm" id="dg-new">${icon('plus', 'icon-sm')}Registrar ausencia</button></div><p class="small muted" style="margin-top:0">Mientras dure la ausencia, las tareas y aprobaciones de la persona pasan a quien la reemplaza.</p><ul class="list" id="dg-l"></ul></section>`,
    mount: (root) => {
      const DG = () => L.store.get('flujos.deleg', [{ quien: 'Ximena Bravo Cortés', rol: 'Jefa de Bodega', reemplazo: 'Supervisor de turno noche', desde: '16-11-2026', hasta: '20-11-2026' }]);
      const drawDG = () => ($('#dg-l', root).innerHTML = DG().map((g) => `<li>${icon('users')}<div class="grow"><div class="title">${esc(g.quien)} → ${esc(g.reemplazo)}</div><div class="sub">${esc(g.rol)} · ${g.desde} a ${g.hasta}</div></div>${L.badge('Programada', 'info')}</li>`).join(''));
      drawDG();
      $('#dg-new', root).onclick = () => L.modal({ title: 'Registrar ausencia', body: `<div class="form-grid"><div class="field"><label for="dg-q">Persona <span class="req" aria-hidden="true">*</span></label><select id="dg-q" class="select"><option value="">Seleccione…</option>${D.profiles.filter((p) => !p.all && p.mfa).map((p) => `<option>${esc(p.name)}</option>`).join('')}</select></div><div class="field"><label for="dg-r">Delega en <span class="req" aria-hidden="true">*</span></label><input id="dg-r" class="input" placeholder="Nombre de quien reemplaza"></div><div class="field"><label for="dg-d">Desde <span class="req" aria-hidden="true">*</span></label><input id="dg-d" class="input" type="date" value="2026-11-16"></div><div class="field"><label for="dg-h">Hasta <span class="req" aria-hidden="true">*</span></label><input id="dg-h" class="input" type="date" value="2026-11-20"></div></div>`, onOpen: (d) => { ['#dg-q', '#dg-r'].forEach((x) => L.bindField($(x, d), ['required'])); L.bindField($('#dg-h', d), [(v) => (v && v >= $('#dg-d', d).value ? '' : 'La fecha de término debe ser igual o posterior al inicio.')]); }, actions: [{ label: 'Cancelar' }, { label: 'Registrar', cls: 'btn-primary', onClick: (api) => { if (!L.validateAll(api.el)) return false; const e = api.el, p = D.profiles.find((x) => x.name === $('#dg-q', e).value); const f2 = (v) => v.split('-').reverse().join('-'); L.store.set('flujos.deleg', [{ quien: p.name, rol: p.actor, reemplazo: $('#dg-r', e).value.trim(), desde: f2($('#dg-d', e).value), hasta: f2($('#dg-h', e).value) }, ...DG()]); L.logAudit('Creación', 'Flujo de trabajo', `Delegación de ${p.name} a ${$('#dg-r', e).value.trim()}`); drawDG(); L.toast('Ausencia registrada', 'Sus tareas pasarán al reemplazo en esas fechas.', 'success'); } }] });
      $$('[data-fl]', root).forEach((b) => (b.onclick = () => {
        const f = FLUJOS().find((x) => x.id === b.dataset.fl);
        L.modal({ title: `Configurar · ${f.nombre}`, size: 'lg', body: `<div class="form-grid"><div class="field" style="grid-column:1/-1"><label for="fl-e">Estados y transiciones (uno por línea, en orden) <span class="req" aria-hidden="true">*</span></label><textarea id="fl-e" class="textarea" rows="5">${esc(f.estados.join('\n'))}</textarea><p class="hint">Cada estado puede pasar al siguiente de la lista; el último es final.</p></div><div class="field"><label for="fl-p">Plazo por etapa (horas) <span class="req" aria-hidden="true">*</span></label><input id="fl-p" class="input num" type="number" min="1" value="${f.plazo}"></div><div class="field"><label for="fl-s">Escalar a <span class="req" aria-hidden="true">*</span></label><select id="fl-s" class="select">${['Jefatura de Bodega', 'Gerencia de Finanzas', 'Jefatura de TI', 'Jefatura de Calidad', 'Gerencia de Operaciones'].map((o) => `<option ${o === f.escala ? 'selected' : ''}>${o}</option>`).join('')}</select></div><div class="field"><label for="fl-h">Horas adicionales antes de escalar <span class="req" aria-hidden="true">*</span></label><input id="fl-h" class="input num" type="number" min="1" value="${f.escalaH}"></div></div>`,
          onOpen: (d) => { L.bindField($('#fl-e', d), [(v) => (v.split('\n').filter((x) => x.trim()).length >= 2 ? '' : 'Defina al menos dos estados.')]); L.bindField($('#fl-p', d), [(v) => (+v >= 1 ? '' : 'El plazo mínimo es 1 hora.')]); L.bindField($('#fl-h', d), [(v) => (+v >= 1 ? '' : 'Mínimo 1 hora.')]); },
          actions: [{ label: 'Cancelar' }, { label: 'Guardar flujo', cls: 'btn-primary', onClick: (api) => { if (!L.validateAll(api.el)) return false; const e = api.el; L.store.set('flujos', FLUJOS().map((x) => (x.id === f.id ? { ...x, estados: $('#fl-e', e).value.split('\n').map((t) => t.trim()).filter(Boolean), plazo: +$('#fl-p', e).value, escala: $('#fl-s', e).value, escalaH: +$('#fl-h', e).value } : x))); L.toast('Flujo actualizado', `${f.nombre}: la nueva versión rige desde ahora y queda en la auditoría.`, 'success'); L.router.resolve(); } }] });
      }));
    }
  });

  L.route('/admin/parametros', {
    title: 'Parámetros', parent: '/inicio', block: 'Administración', module: 'Registro versionado de parámetros', rf: ['RF-17.02', 'RF-17.03', 'RF-02.01', 'RF-09.10', 'RF-17.09', 'RF-16.03'], actors: ['Jefe de TI', 'Gerente de Finanzas', 'Gerente Comercial'],
    render: () => `<div class="page-head"><div class="titles"><h1>Parámetros de negocio</h1><p class="muted" style="margin:0">Umbrales, plazos y tolerancias editables sin desarrollo, con versión, vigencia y aprobación de un segundo perfil.</p></div></div>
      ${L.alert('info', 'Ventanas protegidas', 'Los cambios aprobados se aplican fuera de la ventana de despacho de 05:30 a 07:00 y nunca entre el 1 y el 25 de septiembre, en diciembre ni en los tres primeros días hábiles del mes, por el cierre comercial y contable.')}<div style="height:12px"></div>${L.me()?.id === 'comercial' ? '' : L.alert('warning', ((L.me()?.id === 'ti' || L.me()?.all) ? '1 cambio pendiente de su aprobación' : '1 cambio propuesto, a la espera de un segundo perfil'), 'Umbral de bloqueo de crédito: 10 % → 12 %, propuesto por Patricio Vergara (Finanzas) el 12-11 a las 17:40.', (L.me()?.id === 'ti' || L.me()?.all) ? '<button type="button" class="btn btn-secondary btn-sm" id="pa-rej">Rechazar</button><button type="button" class="btn btn-primary btn-sm" id="pa-ok">Aprobar</button>' : '')}
      <div style="margin-top:var(--sp-5)">${L.tabsHtml('pa', [{ id: 'neg', label: 'Parámetros de negocio' }, ...(L.me()?.id === 'ti' || L.me()?.all) ? [{ id: 'red', label: 'Red logística' }, { id: 'exc', label: 'Excursión térmica' }, { id: 'tpl', label: 'Plantillas' }, { id: 'alr', label: 'Alertas de negocio' }] : []], 'neg')}
      <div ${L.panelAttrs('pa', 'neg', 'neg')}>${D.parametros.filter((g) => { const m = L.me(); return m?.all || m?.id === 'ti' || (m?.id === 'finanzas' && g.grupo === 'Crédito y cobranza') || (m?.id === 'comercial' && g.grupo === 'Sugerencias de preventa'); }).map((g, gi) => L.accordionHtml(esc(g.grupo), `<div class="stack">${g.items.map((it) => `<form class="row-between" data-pf="${it.id}" novalidate style="border-bottom:1px solid var(--c-line-soft);padding-bottom:12px"><div style="flex:1 1 260px"><label for="pa-${it.id}" style="font-weight:600">${esc(it.label)}</label><div class="small muted">Vigente desde 01-10-2026 · versión ${gi + 3}</div></div><div class="field" style="flex:0 0 220px"><div class="input-group"><input id="pa-${it.id}" class="input num" value="${esc(it.valor)}" data-orig="${esc(it.valor)}" aria-describedby="pa-u-${it.id}"><span class="addon" id="pa-u-${it.id}" style="border-left:0;border-right:1px solid var(--c-line);border-radius:0 6px 6px 0">${esc(it.unidad)}</span></div></div><button type="submit" class="btn btn-secondary btn-sm" disabled>Proponer cambio</button></form>`).join('')}</div>`, gi === 0, ` <span class="badge plain" style="margin-left:8px">${g.items.length}</span>`)).join('')}</div>
      <div ${L.panelAttrs('pa', 'red', 'neg')}><div class="row-between" style="margin-bottom:var(--sp-3)"><p class="muted" style="margin:0">Instalaciones de la red y su topología: zonas operativas con su rango de temperatura.</p><button type="button" class="btn btn-primary" id="rl-add">${icon('plus')}Agregar instalación</button></div><div class="card card-flush"><div class="table-wrap"><table class="table"><caption class="sr-only">Instalaciones de la red logística</caption><thead><tr><th>Instalación</th><th>Tipo</th><th>Zonas operativas</th><th class="right">Ocupación</th><th><span class="sr-only">Topología</span></th></tr></thead><tbody id="rl-b">${D.sitios.map((s) => `<tr><td><strong>${esc(s.nombre)}</strong><div class="small muted mono">${s.id}</div></td><td>${esc(s.tipo)}</td><td class="wrap small">${s.zonas ? 'Seco 15 a 25 °C · Refrigerado 2 a 8 °C · Congelado −25 a −18 °C' : 'Andén de transferencia · sin almacenamiento'}</td><td class="num right">${s.ocupacion} %</td><td class="right">${s.zonas ? `<button type="button" class="btn btn-tertiary btn-sm" data-topo="${s.id}">Posiciones</button>` : ''}</td></tr>`).join('')}</tbody></table></div></div></div>
      <div ${L.panelAttrs('pa', 'exc', 'neg')}><p class="muted" style="margin-top:0">Regla de excursión por tipo de producto: cuánto puede desviarse y por cuánto tiempo antes de retener el lote. Estas reglas las propone y aprueba solo Calidad; desde esta consola se consultan.</p><div class="card card-flush"><div class="table-wrap"><table class="table"><caption class="sr-only">Reglas de excursión térmica</caption><thead><tr><th>Tipo de producto</th><th>Rango</th><th>Desviación máxima (°C)</th><th>Duración máxima (min)</th><th><span class="sr-only">Acción</span></th></tr></thead><tbody>${[['Lácteos', '2 a 8 °C', 2, 15], ['Cecinas', '2 a 6 °C', 1.5, 15], ['Producto fresco', '2 a 8 °C', 2, 30], ['Congelados', '−25 a −18 °C', 3, 10]].map(([n, rg, d, m], i) => `<tr><td>${n}</td><td>${rg}</td><td><input class="input num" style="width:90px" value="${d}" data-ex="${i}" aria-label="Desviación máxima para ${n}"></td><td><input class="input num" style="width:90px" value="${m}" data-ex="${i}" aria-label="Duración máxima para ${n}"></td><td class="right"><button type="button" class="btn btn-secondary btn-sm" data-exs="${n}">Proponer cambio</button></td></tr>`).join('')}</tbody></table></div></div></div>
      <div ${L.panelAttrs('pa', 'tpl', 'neg')}><p class="muted" style="margin-top:0">Plantillas que el CLIENTE administra. Cada documento se genera con los datos de la transacción, en formato abierto.</p><ul class="list card">${[['Comprobante de entrega', 'Entrega · cliente · líneas · prueba de entrega'], ['Recibo provisional de cobranza', 'Cliente · facturas · monto'], ['Informe de liquidación por camión', 'Ruta · documentos · efectivo · envases'], ['Acta de disposición sanitaria', 'Lote · excursión · decisión de Calidad']].map(([n, d], i) => `<li>${icon('file')}<div class="grow"><div class="title">${n}</div><div class="sub">Campos: ${d} · versión ${3 + i}</div></div><button type="button" class="btn btn-tertiary btn-sm" data-tpe="${n}">${icon('edit', 'icon-sm')}Editar</button><button type="button" class="btn btn-secondary btn-sm" data-tpg="${n}">${icon('download', 'icon-sm')}Generar</button></li>`).join('')}</ul></div>
      <div ${L.panelAttrs('pa', 'alr', 'neg')}><p class="muted" style="margin-top:0">Alertas por síntomas del negocio, no solo por infraestructura. Agrupan eventos repetidos, suprimen el ruido, escalan si nadie responde y siguen los turnos de disponibilidad.</p><div class="card card-flush"><div class="table-wrap"><table class="table"><caption class="sr-only">Reglas de alerta</caption><thead><tr><th>Síntoma</th><th>Agrupación y supresión</th><th>Escalamiento</th><th>Turno</th><th>Activa</th></tr></thead><tbody>${[['OTIF del día bajo 92 %', 'Una alerta por día', 'Jefa de Bodega → Gerente de Operaciones a los 30 min', 'Operaciones 06:00–22:00'], ['Pedidos sin preparar a las 04:00', 'Agrupa por misión · 15 min', 'Supervisor de turno → Jefa de Bodega a los 20 min', 'Bodega turno noche'], ['Más de 2 excursiones críticas en 1 hora', 'Agrupa por camión · 10 min', 'Jefa de Calidad → Gerente de Operaciones a los 15 min', 'Calidad 24 × 7'], ['Más de 5 pedidos EDI en excepción', 'Agrupa por cadena · 30 min', 'Ejecutivo comercial → Gerente Comercial a los 60 min', 'Comercial 08:00–20:00']].map(([s, g, e, tr], i) => `<tr><td class="wrap"><strong>${s}</strong></td><td class="wrap small">${g}</td><td class="wrap small">${e}</td><td class="small">${tr}</td><td><label class="switch"><input type="checkbox" checked data-al="${i}" aria-label="Activar alerta: ${s}"></label></td></tr>`).join('')}</tbody></table></div></div></div></div>`,
    mount: (root) => {
      L.tabs($('.tabs', root));
      $('#rl-add', root).onclick = () => L.modal({ title: 'Agregar instalación', body: `<div class="form-grid"><div class="field"><label for="rl-n">Nombre <span class="req" aria-hidden="true">*</span></label><input id="rl-n" class="input" placeholder="Plataforma Linares"></div><div class="field"><label for="rl-t">Tipo <span class="req" aria-hidden="true">*</span></label><select id="rl-t" class="select"><option value="">Seleccione…</option><option>Centro de distribución</option><option>Cross-docking</option></select></div></div><fieldset style="margin-top:12px"><legend>Zonas operativas</legend><div class="options-row"><label class="check"><input type="checkbox" checked> Seco (15 a 25 °C)</label><label class="check"><input type="checkbox"> Refrigerado (2 a 8 °C)</label><label class="check"><input type="checkbox"> Congelado (−25 a −18 °C)</label></div></fieldset>`, onOpen: (d) => { L.bindField($('#rl-n', d), ['required']); L.bindField($('#rl-t', d), ['required']); }, actions: [{ label: 'Cancelar' }, { label: 'Agregar', cls: 'btn-primary', onClick: (api) => { if (!L.validateAll(api.el)) return false; const n = $('#rl-n', api.el).value, ty = $('#rl-t', api.el).value; $('#rl-b', root).insertAdjacentHTML('beforeend', `<tr><td><strong>${esc(n)}</strong><div class="small muted">Nueva</div></td><td>${esc(ty)}</td><td class="wrap small">Seco 15 a 25 °C</td><td class="num right">0 %</td></tr>`); L.toast('Instalación agregada', n, 'success'); } }] });
      // RF-02.01: internal topology (zones, aisles, racks, levels, positions); every position belongs to a thermal zone
      const ZR = { Seco: '15 a 25 °C', Refrigerado: '2 a 8 °C', Congelado: '−25 a −18 °C' };
      $$('[data-topo]', root).forEach((b) => (b.onclick = () => { const s = D.sitios.find((x) => x.id === b.dataset.topo); const extra = L.store.get('topo.' + s.id, []); const base = [['A-01-02-1', 'Seco'], ['A-12-04-3', 'Seco'], ['R-2-14-3', 'Refrigerado'], ['R-2-15-1', 'Refrigerado'], ['C-1-02-1', 'Congelado']].map(([c, z]) => ({ c, z })); L.modal({ title: `Topología · ${s.nombre}`, size: 'lg', body: `<p class="muted" style="margin-top:0">Pasillos A (seco, 14), R (refrigerado, 4) y C (congelado, 2) · 6 racks por pasillo · 4 niveles · ${fmt.n(2860 + extra.length)} posiciones con coordenada única. La configuración también está disponible sin conexión en el servidor local del CD.</p><table class="table"><caption class="sr-only">Muestra de posiciones</caption><thead><tr><th>Posición (pasillo-columna-nivel)</th><th>Zona</th><th>Rango</th></tr></thead><tbody>${[...extra, ...base].map((p) => `<tr><td class="mono">${esc(p.c)}</td><td>${esc(p.z)}</td><td>${ZR[p.z]}</td></tr>`).join('')}</tbody></table><h3 style="margin-top:var(--sp-4)">Agregar posición</h3><div class="form-grid"><div class="field"><label for="tp-c">Coordenada <span class="req" aria-hidden="true">*</span></label><input id="tp-c" class="input mono" placeholder="A-14-06-4"></div><div class="field"><label for="tp-z">Zona térmica <span class="req" aria-hidden="true">*</span></label><select id="tp-z" class="select"><option value="">Seleccione…</option>${Object.keys(ZR).map((z) => `<option>${z}</option>`).join('')}</select></div></div>`, onOpen: (d) => { L.bindField($('#tp-c', d), [(v) => (/^[A-Z]-\d{1,2}-\d{2}-\d$/.test(v.trim()) ? ([...extra, ...base].some((p) => p.c === v.trim()) ? 'Esa coordenada ya existe.' : '') : 'Use el formato pasillo-columna-nivel, por ejemplo A-14-06-4.')]); L.bindField($('#tp-z', d), [(v) => (v ? '' : 'No se permite crear posiciones sin zona asignada.')]); }, actions: [{ label: 'Cerrar' }, { label: 'Agregar posición', cls: 'btn-primary', onClick: (api) => { if (!L.validateAll(api.el)) return false; const c = $('#tp-c', api.el).value.trim(), z = $('#tp-z', api.el).value; L.store.set('topo.' + s.id, [{ c, z }, ...extra]); L.logAudit('Creación', 'Topología', `Posición ${c} (${z}, ${ZR[z]}) creada en ${s.nombre}`); L.toast('Posición creada', `${c} · ${z}. El cambio quedó registrado con usuario y fecha.`, 'success'); } }] }); }));
      $$('[data-exs]', root).forEach((b) => { b.disabled = true; b.textContent = 'Las aprueba Calidad'; });
      $$('[data-ex]', root).forEach((i) => (i.disabled = true));
      $$('[data-tpe]', root).forEach((b) => (b.onclick = () => L.modal({ title: `Plantilla · ${b.dataset.tpe}`, size: 'lg', body: `<div class="field"><label for="tp-x">Contenido</label><textarea id="tp-x" class="input" rows="8" style="font-family:var(--font-mono);font-size:var(--fs-sm)">Distribuidora Puelche S.A.\n${b.dataset.tpe}\n\nCliente: {{cliente.nombre}} · RUT {{cliente.rut}}\nFecha: {{fecha}}\nDetalle:\n{{#lineas}}- {{producto}} · {{cantidad}} u{{/lineas}}\n\nTotal: {{total}}</textarea><span class="hint">Los campos entre llaves se reemplazan con los datos de la transacción.</span></div>`, actions: [{ label: 'Cancelar' }, { label: 'Guardar nueva versión', cls: 'btn-primary', onClick: () => L.toast('Plantilla guardada', 'Nueva versión vigente; la anterior queda en el historial.', 'success') }] })));
      $$('[data-tpg]', root).forEach((b) => L.menu(b, [{ title: 'Formato de salida' }, ...['PDF', 'DOCX', 'XLSX'].map((f) => ({ label: f, icon: 'file', onClick: () => L.toast(`${b.dataset.tpg} generado`, `Formato ${f} con datos de la transacción de ejemplo (simulado).`, 'success') }))]));
      $$('[data-al]', root).forEach((s) => (s.onchange = () => L.toast(s.checked ? 'Alerta activada' : 'Alerta desactivada', s.getAttribute('aria-label').replace('Activar alerta: ', ''), 'info', { duration: 2000 })));
      $$('[data-pf]', root).forEach((f) => {
        const inp = $('input', f), btn = $('button', f);
        L.bindField(inp, [(v) => (v === '' ? 'Ingrese un valor.' : /^\d{1,2}:\d{2}$/.test(v) || !isNaN(Number(v)) ? '' : 'Debe ser un número.'), (v) => (Number(v) < 0 ? 'No puede ser negativo.' : '')]);
        inp.addEventListener('input', () => (btn.disabled = inp.value === inp.dataset.orig));
        f.onsubmit = async (e) => { e.preventDefault(); if (!inp._validate()) return; if (await L.confirm({ title: 'Proponer cambio de parámetro', message: `«${esc($('label', f).textContent)}»: ${esc(inp.dataset.orig)} → ${esc(inp.value)}. Tiene impacto operacional: otro perfil debe aprobarlo antes de entrar en vigencia.`, confirmLabel: 'Enviar a aprobación' })) { btn.disabled = true; btn.textContent = 'Pendiente de aprobación'; L.toast('Cambio propuesto', 'Se notificó al perfil aprobador.', 'success'); } };
      });
      const done = (ok) => { L.logAudit(ok ? 'Aprobación' : 'Modificación', 'Parámetro', `Umbral de bloqueo de crédito ${ok ? 'aprobado' : 'rechazado'} por segundo perfil`, 'Consola web', '10 %', ok ? '12 %' : '10 %'); $('.alert', root).outerHTML = L.alert(ok ? 'success' : 'info', ok ? 'Cambio aprobado' : 'Cambio rechazado', ok ? 'Nueva versión vigente desde mañana 00:00. Queda en la auditoría.' : 'Se informó a quien lo propuso.'); };
      if ($('#pa-ok', root)) $('#pa-ok', root).onclick = async () => { if (L.me()?.id === 'finanzas') { L.toast('No puede aprobar su propia propuesta', 'Un segundo perfil distinto de quien propone debe aprobar el cambio.', 'warning'); return; } if (await L.confirm({ title: '¿Aprobar el cambio?', message: 'El umbral de bloqueo de crédito pasará de 10 % a 12 % para todos los preventistas.', confirmLabel: 'Aprobar' })) { done(true); L.toast('Parámetro aprobado', '', 'success'); } };
      if ($('#pa-rej', root)) $('#pa-rej', root).onclick = () => done(false);
    }
  });

  /* ---------- Integrations and monitoring for IT (RF-16.01, RF-16.04; SD3 actor Jefe de TI; Anexo 4-J) ---------- */
  L.route('/admin/integraciones', {
    title: 'Integraciones y monitoreo', parent: '/inicio', block: 'Administración', module: 'Base compartida (observabilidad)', rf: ['RF-16.01', 'RF-16.03', 'RF-16.04', 'RNF-20.05'], actors: ['Jefe de TI'],
    render: () => {
      const edi = L.store.get('edi.down', false), erp = L.store.get('erp.down', false), cd = L.store.get('cd.offline', null);
      const ints = [['ERP (integración erp-sync, Talca)', erp ? 'Caído' : 'En línea', erp ? '—' : '420 ms', erp ? L.store.get('erp.queue', []).length : 0, erp ? 'Sin respuesta del ERP: cola con reintento cada 5 min' : '—'], ['EDI con cadenas', edi ? 'Caído' : 'En línea', edi ? '—' : '1,8 s', edi ? 2 : 0, edi ? 'INC-2291: canal sin conexión' : '—'], ['Telemetría GPS (proveedor actual)', 'En línea', '2,1 s', 0, '—'], ['Gateway de frío e Iridium SBD', 'Degradado', '3 min (satélite)', 4, 'R-05 sin móvil: curva por Iridium'], ['Transbank Webpay', 'En línea', '640 ms', 0, '—'], ['Correo y SMS', 'En línea', '1,2 s', 3, 'Buzón lleno: 1 reintento'], ['Keycloak · identidad', 'En línea', '180 ms', 0, '—'], ['Enlace CD Talca ↔ nube', cd ? 'Caído' : 'En línea', cd ? '—' : '38 ms', L.store.get('cd.queue', []).length, cd ? `Corte desde las ${cd.desde}: puerta local A-01 operando` : '—']];
      const kind = (e) => (e === 'En línea' ? 'success' : e === 'Degradado' ? 'warning' : 'danger');
      return `<div class="page-head"><div class="titles"><h1>Integraciones y monitoreo</h1><p class="muted" style="margin:0">Estado de las interfaces, métricas, registros y trazas correlacionadas por identificador de transacción, e incidentes con su análisis de causa raíz.</p></div></div>
      ${L.tabsHtml('ig', [{ id: 'int', label: 'Interfaces' }, { id: 'tr', label: 'Trazas' }, { id: 'inc', label: 'Incidentes' }, { id: 'cont', label: 'Contingencia' }], 'int')}
      <div ${L.panelAttrs('ig', 'int', 'int')}><section class="card card-flush"><div class="table-wrap"><table class="table"><caption class="sr-only">Estado de las interfaces</caption><thead><tr><th>Interfaz</th><th>Estado</th><th class="right">Latencia p95</th><th class="right">En cola</th><th>Último evento</th></tr></thead><tbody>${ints.map(([n, e, l, q, x]) => `<tr><td>${esc(n)}</td><td>${L.badge(e, kind(e))}</td><td class="num right">${l}</td><td class="num right">${q}</td><td class="wrap small">${esc(x)}</td></tr>`).join('')}</tbody></table></div><p class="small muted" style="padding:var(--sp-3) var(--sp-5) var(--sp-4)">Métricas, registros y trazas de nube y on-premise en una sola consola, instrumentadas con OpenTelemetry. Las alertas de negocio se configuran en Parámetros.</p></section></div>
      <div ${L.panelAttrs('ig', 'tr', 'int')}><section class="card"><form class="row" id="tr-f" novalidate><div class="field" style="flex:1 1 280px"><label for="tr-id">Identificador de transacción o de pedido</label><input id="tr-id" class="input mono" value="${D.pedidos[0].id}" placeholder="Identificador de ejemplo"></div><button type="submit" class="btn btn-primary" style="align-self:flex-end">${icon('search')}Ver traza</button></form><div id="tr-out" style="margin-top:var(--sp-4)"></div></section></div>
      <div ${L.panelAttrs('ig', 'inc', 'int')}><section class="card card-flush"><div class="table-wrap"><table class="table"><caption class="sr-only">Incidentes críticos y causa raíz</caption><thead><tr><th>Incidente</th><th>Severidad</th><th>Inicio</th><th>Informe de causa raíz</th><th class="right">Acciones abiertas</th><th><span class="sr-only">Ver</span></th></tr></thead><tbody>${[['INC-2288', 'Ventana 05:30–07:00: 14 guías sin emitir', 'Crítico', '10-11 05:42', 'Entregado 12-11 (2 días hábiles)', 1], ['INC-2275', 'Excursión térmica sin alerta en R-09', 'Crítico', '04-11 08:10', 'Entregado 07-11 (3 días hábiles)', 0], ['INC-2291', 'Canal EDI sin conexión', 'Alto', 'Hoy', 'Vence 20-11 (5 días hábiles)', 2]].map(([id, t, s, d, r, a]) => `<tr><td><strong class="mono">${id}</strong><div class="small">${esc(t)}</div></td><td>${L.badge(s, s === 'Crítico' ? 'danger' : 'warning')}</td><td>${d}</td><td class="small">${r}</td><td class="num right">${a}</td><td class="right"><button type="button" class="btn btn-tertiary btn-sm" data-rca="${id}">Ver</button></td></tr>`).join('')}</tbody></table></div><p class="small muted" style="padding:var(--sp-3) var(--sp-5) var(--sp-4)">Tras cada incidente crítico se entrega un análisis de causa raíz en 5 días hábiles, con seguimiento de las acciones correctivas hasta su cierre.</p></section></div>
      <div ${L.panelAttrs('ig', 'cont', 'int')}><section class="card"><p class="muted" style="margin-top:0">Qué sigue funcionando si se cae cada pieza.</p><table class="table"><caption class="sr-only">Funciones sin conexión</caption><thead><tr><th>Si falla</th><th>Qué sigue operando</th><th>Al reconectar</th></tr></thead><tbody>${[['Tablero central', 'Alarmas y bitácora local de cada CD sostienen el despacho', 'Se repone telemetría y estado'], ['Enlace del CD con la nube', 'Recepción, inventario, preparación y liberación sanitaria en la puerta local A-01 (24 h)', 'Eventos a la nube y conciliación'], ['ERP', 'Recepciones y rendiciones se cierran; los envíos quedan en cola', 'Reintento automático sin digitación'], ['Ruteo y mapas en línea', 'Secuencia y mapas precargados', 'Se recalculan los cambios sin confirmar'], ['Canal EDI', 'Incidente y aviso acordado con la cadena', 'Cola y bandeja de excepciones'], ['Red móvil en ruta', 'Entrega, POD, cobro en efectivo y alarmas de frío en el terminal', 'Sincronización sin duplicados'], ['Autorización POS', 'Efectivo o crédito autorizado; nunca cargo presunto', 'Se autoriza una sola vez']].map(([a, b, c]) => `<tr><td><strong>${a}</strong></td><td class="wrap small">${b}</td><td class="wrap small">${c}</td></tr>`).join('')}</tbody></table><div class="row" style="margin-top:var(--sp-4)"><button type="button" class="btn btn-secondary" id="ct-dash">Simular caída del tablero central</button></div><div id="ct-out" style="margin-top:var(--sp-3)"></div></section></div>`;
    },
    mount: (root) => {
      L.tabs($('.tabs', root));
      $('#tr-f', root).onsubmit = (e) => { e.preventDefault(); const query = $('#tr-id', root).value.trim().toUpperCase(); const traceId = (order) => 'trace-' + order.id.replace(/\D/g, '') + 'a9f'; const order = D.pedidos.find((p) => p.id === query || traceId(p).toUpperCase() === query); if (!order) { $('#tr-out', root).innerHTML = L.alert('warning', 'Sin resultados', query ? 'No existe una traza de ejemplo para ese identificador.' : 'Ingrese un identificador de pedido o de traza.'); return; } const id = order.id, tid = traceId(order); const spans = [['portal-clientes / app-preventa', 'Envío del pedido', 0, 120], ['api-gateway', 'Autenticación (Keycloak)', 20, 40], ['m3-preventa', 'Validación del pedido', 60, 180], ['m2-inventario', 'Reserva de stock por orden de llegada', 240, 95], ['m7-cobranza', 'Control de crédito', 250, 130], ['erp-sync (VM-04)', 'Registro en el ERP por ACL', 390, 420]]; const tot = 810; $('#tr-out', root).innerHTML = `<p class="small muted" style="margin-top:0">Traza simulada <span class="mono">${esc(tid)}</span> de ${esc(id)} · ${tot} ms · ejemplo ilustrativo; no corresponde a registros operativos.</p><div class="stack">${spans.map(([s, t, st, d]) => `<div><div class="row-between small"><span><strong>${s}</strong> · ${t}</span><span class="num">${d} ms</span></div><div style="position:relative;height:10px;background:var(--c-surface-2);border-radius:4px"><span style="position:absolute;left:${(st / tot) * 100}%;width:${(d / tot) * 100}%;top:0;bottom:0;background:var(--chart-1);border-radius:4px"></span></div></div>`).join('')}</div><table class="table" style="margin-top:var(--sp-4)"><caption class="sr-only">Registros correlacionados</caption><thead><tr><th>Hora</th><th>Servicio</th><th>Registro</th></tr></thead><tbody>${[['09:42:10.112', 'm3-preventa', `INFO pedido ${esc(id)} recibido · uuid local verificado`], ['09:42:10.352', 'm2-inventario', 'INFO reserva firme 4 líneas · correlativo 88213'], ['09:42:10.922', 'erp-sync', 'INFO nota de venta registrada · sin datos personales en el registro']].map(([h, s, m]) => `<tr><td class="mono small">${h}</td><td class="mono small">${s}</td><td class="small">${m}</td></tr>`).join('')}</tbody></table>`; L.logConsulta('Observabilidad', `Traza ${tid} de ${id}`, 'soporte técnico'); };
      $$('[data-rca]', root).forEach((b) => (b.onclick = () => { const id = b.dataset.rca; L.modal({ title: `Causa raíz · ${id}`, body: id === 'INC-2291' ? L.alert('info', 'Informe en preparación', 'Plazo: 5 días hábiles desde el inicio (vence el 20-11).') : `<dl class="desc-list"><dt>Causa raíz</dt><dd>${id === 'INC-2288' ? 'Certificado del canal tributario vencido en la integración erp-sync.' : 'Umbral del sensor configurado en la familia equivocada tras un cambio de parámetro.'}</dd><dt>Acciones correctivas</dt><dd>${id === 'INC-2288' ? 'Alerta 30 días antes del vencimiento (cerrada) · prueba de emisión diaria a las 05:00 (en curso)' : 'Doble aprobación del parámetro (cerrada) · prueba de alarma semanal (cerrada)'}</dd><dt>Entregado al CLIENTE</dt><dd>Dentro de 5 días hábiles</dd></dl>`, actions: [{ label: 'Cerrar', cls: 'btn-primary' }] }); }));
      $('#ct-dash', root).onclick = (e) => L.busy(e.currentTarget, () => { $('#ct-out', root).innerHTML = L.alert('warning', 'Tablero central no disponible (simulación)', 'Cada CD sigue despachando con sus alarmas y la bitácora local de la puerta A-01. Al volver el tablero, se repone la telemetría y el estado de cada ruta sin perder eventos.'); L.logAudit('Creación', 'Integración', 'Simulación de caída del tablero central: despacho con alarmas y bitácora local', 'Consola web'); }, 700);
    }
  });

  L.route('/admin/auditoria', {
    title: 'Auditoría', parent: '/inicio', block: 'Administración', module: 'Registro de auditoría inalterable', rf: ['RF-17.04', 'RF-17.05', 'RNF-09.03', 'RNF-01.02', 'RNF-08.02', 'RNF-09.02', 'RNF-15.03', 'RNF-17.01'], actors: ['Jefe de TI', 'Gerencias'],
    render: () => `<div class="page-head"><div class="titles"><h1>Auditoría</h1><p class="muted" style="margin:0">Toda operación que crea, modifica o elimina información, y toda consulta de información sensible (trazabilidad, antecedentes comerciales, pago y geolocalización) con su finalidad, conforme a la Ley 21.719.</p></div><div class="actions"><button type="button" class="btn btn-secondary" id="au-json">${icon('download')}JSON</button><button type="button" class="btn btn-primary" id="au-csv">${icon('download')}Exportar CSV</button></div></div>
      <section class="card" style="margin-bottom:var(--sp-4)"><div class="form-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr))"><div class="field"><label for="au-d1">Desde</label><input id="au-d1" class="input" type="date" value="2026-11-06"></div><div class="field"><label for="au-d2">Hasta</label><input id="au-d2" class="input" type="date" value="2026-11-13"></div><div class="field combo"><label for="au-p">Persona</label><input id="au-p" class="input" placeholder="Cualquiera"></div><div class="field"><label for="au-o">Operación</label><select id="au-o" class="select"><option value="">Todas</option>${[...new Set(D.auditoria.map((a) => a.operacion))].map((o) => `<option>${o}</option>`).join('')}</select></div></div><div id="au-err" aria-live="polite"></div></section>
      ${L.alert('info', 'Registro inalterable', 'Cada evento se encadena con el resumen criptográfico del anterior: ningún perfil, incluido el de TI, puede editarlo ni eliminarlo. La hora se registra con zona horaria (America/Santiago, GMT−3).')}<div style="height:16px"></div>
      <div class="card card-flush" id="au-t"></div>
      <section class="card" style="margin-top:var(--sp-5)"><div class="card-head"><h2>Retención de registros</h2><button type="button" class="btn btn-secondary btn-sm" id="au-rest">${icon('history', 'icon-sm')}Restaurar una muestra</button></div><div class="table-wrap"><table class="table"><caption class="sr-only">Plazos de retención por tipo de dato</caption><thead><tr><th>Tipo de dato</th><th>Plazo mínimo</th></tr></thead><tbody>${[['Trazabilidad sanitaria y no conformidades de recepción', '5 años'], ['Documentos de referencia tributaria de recepción', '6 años'], ['Devoluciones y mermas: trazabilidad sanitaria', '5 años'], ['Devoluciones y mermas con efecto tributario (notas de crédito)', '6 años'], ['Registros sanitarios y de trazabilidad de lote', 'Vida útil + 6 meses, mínimo 5 años'], ['Registros de temperatura de cámaras y camiones', '5 años'], ['Evidencia de entrega (firma, foto, nombre)', '6 años'], ['Documentos tributarios y su respaldo', '6 años'], ['Geolocalización de personas', '12 meses'], ['Registro de auditoría, incluidas las consultas', 'Mínimo 5 años']].map((r) => `<tr>${r.map((c, i) => `<td class="${i === 2 ? 'mono small' : 'wrap'}">${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div><p class="small muted" style="padding:0 var(--sp-5) var(--sp-4)">Los registros vencidos pasan a archivo y se pueden restaurar para una inspección.</p></section>`,
    mount: (root) => {
      $('#au-rest', root).onclick = () => L.modal({ title: 'Restaurar una muestra archivada', body: `<div class="field"><label for="rs-t">Registro <span class="req" aria-hidden="true">*</span></label><select id="rs-t" class="select"><option value="">Seleccione…</option><option>Recepción OC-71102 · 14-03-2021 · con no conformidad</option><option>Nota de crédito NC-20488 · 02-08-2020 · devolución</option><option>Lote L2103-12 · trazabilidad sanitaria · 2021</option></select></div><p class="hint">Restauración desde el archivo de largo plazo (simulada).</p>`, onOpen: (d) => L.bindField($('#rs-t', d), ['required']), actions: [{ label: 'Cancelar' }, { label: 'Restaurar', cls: 'btn-primary', onClick: (api) => { if (!L.validateAll(api.el)) return false; const r = $('#rs-t', api.el).value; L.logConsulta('Archivo', `Restauración de ${r.split(' ·')[0]}`, 'inspección de retención'); L.toast('Muestra restaurada', `${r.split(' ·')[0]} disponible para consulta; la restauración quedó en la auditoría.`, 'success'); } }] });
      const rows = () => {
        const d1 = $('#au-d1', root).value, d2 = $('#au-d2', root).value, p = $('#au-p', root).value.toLowerCase(), o = $('#au-o', root).value;
        return [...L.store.get('audit.consultas', []), ...D.auditoria].filter((a) => a.fecha.slice(0, 10) >= d1 && a.fecha.slice(0, 10) <= d2 && (!p || a.persona.toLowerCase().includes(p)) && (!o || a.operacion === o));
      };
      const tbl = L.dataTable($('#au-t', root), {
        id: 'aut', caption: 'Registro de auditoría', rows, per: 12, searchKeys: ['detalle', 'entidad', 'id'], searchPlaceholder: 'Buscar en el detalle', sort: 'fecha', dir: 'desc',
        filters: [{ key: 'entidad', label: 'Entidad', options: [...new Set(D.auditoria.map((a) => a.entidad))] }, { key: 'origen', label: 'Origen', options: ['Consola web', 'App móvil', 'API', 'Portal de clientes'] }],
        columns: [{ key: 'fecha', label: 'Fecha y hora', render: (r) => `<span class="mono small">${fmt.dt(r.fecha)} GMT−3</span>` }, { key: 'persona', label: 'Persona' }, { key: 'operacion', label: 'Operación', render: (r) => L.badge(r.operacion, r.operacion === 'Eliminación' ? 'danger' : r.operacion === 'Aprobación' ? 'success' : r.operacion === 'Modificación' ? 'warning' : 'info') }, { key: 'entidad', label: 'Entidad' }, { key: 'detalle', label: 'Detalle', wrap: true }, { key: 'valores', label: 'Antes → después', wrap: true, render: (r) => { const m = r.antes != null ? [r.antes, r.despues] : (r.detalle.match(/([^:·]+?) → ([^·]+)/) || []).slice(1); return m.length ? `<span class="small"><s class="muted">${esc(m[0].trim())}</s> → ${esc(m[1].trim())}</span>` : '<span class="small muted">—</span>'; } }, { key: 'origen', label: 'Origen', render: (r) => `${esc(r.origen)}<div class="small muted mono">${r.ip}</div><div class="small muted mono" title="Resumen encadenado">#${(parseInt(String(r.id).replace(/\D/g, '').slice(-6) || '7', 10) * 2654435761 % 4294967296).toString(16).slice(0, 8)}</div>` }]
      });
      L.combobox($('#au-p', root), () => D.usuarios.map((u) => ({ label: u.nombre, meta: roleName(u.rol) })), { onSelect: () => tbl.draw() });
      ['#au-d1', '#au-d2', '#au-o', '#au-p'].forEach((s) => $(s, root).addEventListener('change', () => {
        const bad = $('#au-d1', root).value > $('#au-d2', root).value;
        $('#au-err', root).innerHTML = bad ? L.alert('danger', 'Rango de fechas no válido', 'La fecha «Desde» debe ser anterior o igual a «Hasta».') : '';
        if (!bad) { tbl.state.page = 1; tbl.draw(); }
      }));
      const cols = [{ label: 'Fecha', key: 'fecha' }, { label: 'Persona', key: 'persona' }, { label: 'Operación', key: 'operacion' }, { label: 'Entidad', key: 'entidad' }, { label: 'Detalle', key: 'detalle' }, { label: 'Origen', key: 'origen' }, { label: 'IP', key: 'ip' }];
      $('#au-csv', root).onclick = (e) => L.busy(e.currentTarget, () => { L.download('auditoria.csv', L.toCSV(tbl.filtered(), cols)); L.toast('Auditoría exportada', `${tbl.filtered().length} registros con el filtro aplicado (CSV UTF-8).`, 'success'); }, 700);
      $('#au-json', root).onclick = (e) => L.busy(e.currentTarget, () => { L.download('auditoria.json', JSON.stringify(tbl.filtered(), null, 2), 'application/json'); L.toast('Auditoría exportada', 'Formato JSON.', 'success'); }, 700);
    }
  });
})(window.LFX);
